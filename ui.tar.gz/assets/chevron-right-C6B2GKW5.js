import{t as r}from"./createLucideIcon-BbGh1zGm.js";var t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],o=r("chevron-right",t);export{o as t};
